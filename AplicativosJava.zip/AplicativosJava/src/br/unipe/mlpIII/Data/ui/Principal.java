package br.unipe.mlpIII.Data.ui;
import br.unipe.mlpIII.Data.modelo.Data;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Data d = new Data();
		
		d.setDia(24);
		d.setMes(5);
		d.setAno(2016);
		
		System.out.println(d);

	}

}
