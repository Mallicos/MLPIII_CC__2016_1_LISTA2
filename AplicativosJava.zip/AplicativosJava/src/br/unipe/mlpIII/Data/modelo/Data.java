package br.unipe.mlpIII.Data.modelo;

public class Data {
	
	private int dia;
	private int mes;
	private int ano;
	
	public Data(){
		
	}
	
	public Data(int dia, int mes, int ano){
		
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
	}
	
    public Data(int dia, int mes){
		
		this.dia = dia;
		this.mes = mes;
		this.ano = 2016;
	}

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		
		if(dia < 0)
		    this.dia = 0;
		
		else if(dia > 31)
			this.dia = 0;
		
		else
			this.dia = dia;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		
		if(mes < 0)
			this.mes = 0;
		
		else if(mes > 12)
			this.mes = 0;
		
		else
		    this.mes = mes;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		
		if(ano < 0)
			this.ano = 0;
		
		else
		    this.ano = ano;
	}
	
	public String toString(){
		return dia+ "/" + mes+ "/" + ano;
	}

}