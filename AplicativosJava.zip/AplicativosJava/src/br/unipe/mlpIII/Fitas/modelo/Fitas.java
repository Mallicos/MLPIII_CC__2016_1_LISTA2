package br.unipe.mlpIII.Fitas.modelo;

public abstract class Fitas {
	
	protected  double locacao;
	protected String titulo;
	protected static String categoria;
	
	public void precoLocacao(){}

}
