package br.unipe.mlpIII.Fitas.modelo;

public class FitaLancamento extends Fitas{
	
    public FitaLancamento(String titulo, String categoria, double locacao){
		
    	this.titulo = titulo;
    	this.categoria = categoria;
    	this.locacao = locacao;
	}
    
    public void precoLocacao(){
    	
    	this.locacao = locacao + (locacao * 0.40);
    	
    	if(this.locacao < 0)
    		this.locacao = 0;
    }
    
    public String toString(){
    	
    	return "T�tulo: "+this.titulo+"\nCategoria: "+this.categoria+"\nLoca��o: "+this.locacao;
    }
	

}
