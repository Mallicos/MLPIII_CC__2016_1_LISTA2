package br.unipe.mlpIII.Fitas.modelo;

public class Autor {
	
	private String autor;
	
	public Autor(String autor){
		
		this.autor = autor;
	}
	
	public String toString(){
		return "\nAutor: "+autor;
	}

}
