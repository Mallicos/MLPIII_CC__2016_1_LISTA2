package br.unipe.mlpIII.Fitas.ui;

import java.util.Scanner;

import br.unipe.mlpIII.Fitas.modelo.Autor;
import br.unipe.mlpIII.Fitas.modelo.FitaInfantil;
import br.unipe.mlpIII.Fitas.modelo.FitaLancamento;
import br.unipe.mlpIII.Fitas.modelo.Fitas;

public class Main {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Informe o t�tulo do filme: ");
		String titulo = input.next();
		
		System.out.println("Informe o nome do autor do filme: ");
		String autor = input.next();
		
		System.out.println("Informe a categoria do filme: ");
		String categoria = input.next();
		
		System.out.println("Informe o valor da loca��o: ");
		double locacao = input.nextDouble();
		
		System.out.println("informe o tipo da fita: 1=lan�amento; 2=infantil");
		int tipo = input.nextInt();
		
		input.close();
		
		switch(tipo){
		case 1:{
			
			Fitas f = new FitaLancamento(titulo, categoria, locacao);
			f.precoLocacao();
			Autor a1 = new Autor(autor);
			System.out.print(f);
			System.out.print(a1);
			break;
		}
		
		case 2:{
			
			Fitas i = new FitaInfantil(titulo, categoria, locacao);
			i.precoLocacao();
			Autor a2 = new Autor(autor);
			System.out.print(i);
			System.out.print(a2);
			break;
		}
		}	
	}

}
