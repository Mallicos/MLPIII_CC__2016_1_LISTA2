package br.unipe.mlpIII.Veiculo.ui;
import java.util.Scanner;

import br.unipe.mlpIII.Veiculo.modelo.Pessoa;
import br.unipe.mlpIII.Veiculo.modelo.Veiculo;
import br.unipe.mlpIII.Veiculo.modelo.VeiculoCarga;
import br.unipe.mlpIII.Veiculo.modelo.VeiculoPasseio;

public class Main {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Informe o nome do proprietario: ");
		String proprietario = input.next();
		
		System.out.println("Informe a placa: ");
		String placa = input.next();
		
		System.out.println("Informe a marca: ");
		String marca = input.next();
		
		System.out.println("Informe o modelo: ");
		String modelo = input.next();
		
		System.out.println("Informe o ano: ");
		int ano = input.nextInt();
		
		System.out.println("Informe os kmRodados: ");
		double kmRodados = input.nextDouble();
		
		System.out.println("Informe o kmInicial: ");
		double kmInicial = input.nextDouble();
		
		System.out.println("Informe o kmFinal: ");
		double kmFinal = input.nextDouble();
		
		System.out.println("Informe o chassi: ");
		String chassi = input.next();
		
		System.out.println("Informe o tipo de ve�culo: 1-Passeio; 2-Carga.");
		int tipo = input.nextInt();
		
		switch(tipo){
		case 1:{
			System.out.println("Informe se tem ar-condicionado: 1=sim; 2=n�o");
			int arCondicionado = input.nextInt();
			
			boolean arCondicionado2;
			
			if(arCondicionado == 1){
				 arCondicionado2 = true;
			}
			else{
				 arCondicionado2 = false;
			}
				
			System.out.println("Informe a quantidade de portas: ");
			int qtdPortas = input.nextInt();
			
			Veiculo v1 = new VeiculoPasseio(placa, marca, modelo, ano, kmRodados, kmInicial, kmFinal, 0, chassi, 
					                        arCondicionado2, qtdPortas);
			
			double resultado = v1.locacao(kmRodados, kmInicial, kmFinal);
			
			System.out.print(v1);
			System.out.print("Valor da loca��o: "+resultado);
			
			Pessoa pessoa = new Pessoa(proprietario);
			System.out.print(pessoa);
			break;
		}
		
		case 2:{
			System.out.println("Informe a capacidade de carga do ve�culo: ");
			double carga = input.nextDouble();
			
			Veiculo v2 = new VeiculoCarga(placa, marca, modelo, ano, kmRodados, kmInicial,
					                      kmFinal, 0, chassi, carga);
			
			double resultado = v2.locacao(kmRodados, kmInicial, kmFinal);
			
			System.out.print(v2);
			System.out.print("Valor da loca��o: "+resultado);
			
			Pessoa pessoa = new Pessoa(proprietario);
			System.out.print(pessoa);
			break;
		}
		
		}

	}

}
