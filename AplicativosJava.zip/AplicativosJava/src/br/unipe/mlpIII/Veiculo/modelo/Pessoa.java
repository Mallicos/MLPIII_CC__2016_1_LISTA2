package br.unipe.mlpIII.Veiculo.modelo;

public class Pessoa {
	
	private String proprietario;
	
	public Pessoa(String proprietario){
		
		this.proprietario = proprietario;
	}
	
	public String toString(){
		
		return "\nProprietario: "+this.proprietario;
	}

}
