package br.unipe.mlpIII.Veiculo.modelo;

public class VeiculoCarga extends Veiculo{
	
	private double carga;
	
	public VeiculoCarga(String placa, String marca, String modelo, int ano, double kmRodados,
			            double kmInicial, double kmFinal, double valorLocacao, String chassi, 
			            double carga){
	
		
		this.placa = placa;
		this.marca = marca;
		this.modelo = modelo;
		this.ano = ano;
		this.kmRodados = kmRodados;
		this.kmInicial = kmInicial;
		this.kmFinal = kmFinal;
		this.valorLocacao = valorLocacao;
		this.chassi = chassi;
		this.carga = carga;
	}
	
	public String toString(){
		return "Placa: "+this.placa+"\nMarca: "+this.marca+"\nModelo: "+this.modelo+"\nAno: "+this.ano+"\nKm rodados: "+this.kmRodados+
				"\nKm inicial: "+this.kmInicial+"\nKm final: "+this.kmFinal+"\nChassi: "+this.chassi+
				"\nCapacidade de Carga: "+this.carga+"\n";
	}
                         
	

}
