package br.unipe.mlpIII.Veiculo.modelo;

public class VeiculoPasseio extends Veiculo{
	
	private boolean arCondicionado;
	private int qtdPortas;
	
	public VeiculoPasseio(String placa, String marca, String modelo, int ano, double kmRodados, double kmInicial,
			              double kmFinal, double valorLocacao, String chassi, boolean arCondicionado2, int qtdPortas){
		
		this.placa = placa;
		this.marca = marca;
		this.modelo = modelo;
		this.ano = ano;
		this.kmRodados = kmRodados;
		this.kmInicial = kmInicial;
		this.kmFinal = kmFinal;
		this.valorLocacao = valorLocacao;
		this.chassi = chassi;
		this.arCondicionado = arCondicionado2;
		this.qtdPortas = qtdPortas;
	}
	
	public String toString(){
		return "Placa: "+this.placa+"\nMarca: "+this.marca+"\nModelo: "+this.modelo+"\nAno: "+this.ano+"\nKm rodados: "+this.kmRodados+
				"\nKm inicial: "+this.kmInicial+"\nKm final: "+this.kmFinal+"\nChassi: "+this.chassi+
				"\nAr-Condicionado: "+this.arCondicionado+"\nQuantidade de portas: "+this.qtdPortas+"\n";
	}

}
