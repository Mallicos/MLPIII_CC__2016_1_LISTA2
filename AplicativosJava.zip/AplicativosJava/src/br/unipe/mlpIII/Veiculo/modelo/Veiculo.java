package br.unipe.mlpIII.Veiculo.modelo;

public abstract class Veiculo {
	
	protected String placa;
	protected String marca;
	protected String modelo;
	protected int ano;
	protected double kmRodados;
	protected double kmInicial;
	protected double kmFinal;
	protected double valorLocacao;
	protected String chassi;
	
	public double locacao(double kmRodados, double kmInicial, double kmFinal){
		
		 this.valorLocacao = (kmInicial - kmFinal) * kmRodados;
		 
		 if(this.valorLocacao < 0)
			 this.valorLocacao = 0;
		 
		 return valorLocacao;
	}

}
